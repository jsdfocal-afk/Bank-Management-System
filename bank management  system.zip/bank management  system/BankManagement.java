import java.sql.*;
import java.util.Scanner;

public class BankManagement {

    static Scanner sc = new Scanner(System.in);

    public static void createAccount() {
        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Account Number: ");
            String accNo = sc.nextLine();

            System.out.print("Holder Name: ");
            String name = sc.nextLine();

            System.out.print("Initial Balance: ");
            double balance = sc.nextDouble();
            sc.nextLine();

            String sql =
                "INSERT INTO accounts VALUES(?,?,?)";

            PreparedStatement ps =
                con.prepareStatement(sql);

            ps.setString(1, accNo);
            ps.setString(2, name);
            ps.setDouble(3, balance);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Account Created Successfully!");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewAccounts() {
        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();

            ResultSet rs =
                st.executeQuery("SELECT * FROM accounts");

            System.out.println("\n--- ACCOUNT LIST ---");

            while (rs.next()) {
                System.out.println(
                    rs.getString("account_number")
                    + " | "
                    + rs.getString("holder_name")
                    + " | ₹"
                    + rs.getDouble("balance"));
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void depositMoney() {
        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Account Number: ");
            String accNo = sc.nextLine();

            System.out.print("Deposit Amount: ");
            double amount = sc.nextDouble();
            sc.nextLine();

            PreparedStatement ps =
                con.prepareStatement(
                    "UPDATE accounts SET balance=balance+? WHERE account_number=?");

            ps.setDouble(1, amount);
            ps.setString(2, accNo);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Deposit Successful!");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void withdrawMoney() {
        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Account Number: ");
            String accNo = sc.nextLine();

            System.out.print("Withdraw Amount: ");
            double amount = sc.nextDouble();
            sc.nextLine();

            PreparedStatement check =
                con.prepareStatement(
                    "SELECT balance FROM accounts WHERE account_number=?");

            check.setString(1, accNo);

            ResultSet rs = check.executeQuery();

            if (rs.next()) {

                double balance =
                    rs.getDouble("balance");

                if (balance >= amount) {

                    PreparedStatement ps =
                        con.prepareStatement(
                            "UPDATE accounts SET balance=balance-? WHERE account_number=?");

                    ps.setDouble(1, amount);
                    ps.setString(2, accNo);

                    ps.executeUpdate();

                    System.out.println("Withdrawal Successful!");
                } else {
                    System.out.println("Insufficient Balance!");
                }
            } else {
                System.out.println("Account Not Found!");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteAccount() {
        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Account Number: ");
            String accNo = sc.nextLine();

            PreparedStatement ps =
                con.prepareStatement(
                    "DELETE FROM accounts WHERE account_number=?");

            ps.setString(1, accNo);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Account Deleted Successfully!");
            else
                System.out.println("Account Not Found!");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        while (true) {

            System.out.println("\n===== BANK MANAGEMENT SYSTEM =====");
            System.out.println("1. Create Account");
            System.out.println("2. View Accounts");
            System.out.println("3. Deposit Money");
            System.out.println("4. Withdraw Money");
            System.out.println("5. Delete Account");
            System.out.println("6. Exit");

            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    createAccount();
                    break;

                case 2:
                    viewAccounts();
                    break;

                case 3:
                    depositMoney();
                    break;

                case 4:
                    withdrawMoney();
                    break;

                case 5:
                    deleteAccount();
                    break;

                case 6:
                    System.out.println("Thank You!");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}