CREATE DATABASE bank_db;

USE bank_db;

CREATE TABLE accounts (
    account_number VARCHAR(20) PRIMARY KEY,
    holder_name VARCHAR(100) NOT NULL,
    balance DOUBLE NOT NULL
);